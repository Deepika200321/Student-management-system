public interface GradeCalculator {
    String calculateGrade(int marks);
}
