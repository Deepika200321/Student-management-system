import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        // Take input for Student
        System.out.print("Enter Student Name: ");
        String sName = sc.nextLine();
        System.out.print("Enter Age: ");
        int sAge = sc.nextInt();
        System.out.print("Enter Student ID: ");
        int sId = sc.nextInt();

        Student s1 = new Student(sName, sAge, sId);
        s1.displayInfo();

        System.out.print("Enter Marks to calculate grade: ");
        int sMarks = sc.nextInt();
        System.out.println("Grade: " + s1.calculateGrade(sMarks));

        System.out.println();

        sc.nextLine(); // consume leftover newline

        // Input for Graduate Student
        System.out.print("Enter Graduate Student Name: ");
        String gsName = sc.nextLine();
        System.out.print("Enter Age: ");
        int gsAge = sc.nextInt();
        System.out.print("Enter Student ID: ");
        int gsId = sc.nextInt();
        sc.nextLine(); // consume newline
        System.out.print("Enter Research Topic: ");
        String topic = sc.nextLine();

        GraduateStudent gs1 = new GraduateStudent(gsName, gsAge, gsId, topic);
        gs1.displayInfo();

        System.out.print("Enter Marks to calculate grade: ");
        int gsMarks = sc.nextInt();
        System.out.println("Grade: " + gs1.calculateGrade(gsMarks));

        System.out.println();

        // Input for Course
        sc.nextLine(); // consume newline
        System.out.print("Enter Course Name: ");
        String courseName = sc.nextLine();
        System.out.print("Enter Credits: ");
        int credits = sc.nextInt();

        Course c1 = new Course(courseName, credits);
        c1.displayCourseInfo();

        System.out.println();

        // Show total students
        Student.showStudentCount();

        sc.close();
    }
}
