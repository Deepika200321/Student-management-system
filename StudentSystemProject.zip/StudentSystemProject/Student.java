public class Student extends Person implements GradeCalculator {
    int studentId;
    static int studentCount = 0; // Static variable to count students

    // Constructor (Overloading)
    public Student(String name, int age, int studentId) {
        super(name, age); // calling Person constructor
        this.studentId = studentId;
        studentCount++;
    }

    // Method Overriding
    public void displayInfo() {
        super.displayInfo(); // show name and age
        System.out.println("Student ID: " + studentId);
    }

    // Static method to show student count
    public static void showStudentCount() {
        System.out.println("Total Students: " + studentCount);
    }

    // Interface method (Grade Calculator)
    public String calculateGrade(int marks) {
        if (marks >= 90) return "A";
        else if (marks >= 75) return "B";
        else if (marks >= 60) return "C";
        else return "F";
    }
}
