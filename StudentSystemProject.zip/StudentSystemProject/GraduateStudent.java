public class GraduateStudent extends Student {
    String thesisTopic;

    public GraduateStudent(String name, int age, int studentId, String thesisTopic) {
        super(name, age, studentId);
        this.thesisTopic = thesisTopic;
    }

    public void displayInfo() {
        super.displayInfo();
        System.out.println("Thesis Topic: " + thesisTopic);
    }
}
